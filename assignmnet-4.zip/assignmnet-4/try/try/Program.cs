﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

using System;
namespace MyApplication
{
    class Program
    {
        private string name;
        public string Name;
    }
}

class Person
{
    static void Mina(string[] args)
    {
        Person myObj = new Person();
        myObj.Name = "Elias";
        Console.WriteLine(myObj.Name);
    }
}

